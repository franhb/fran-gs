Light Theme for GetSimple Content Management System

============================================================================================
DESCRIPTION:

Light theme is a html5 and css3 verified theme for GetSimple v3.1 or higher. 

Theme Developer Website: http://blog.orkunsoylu.com/
GetSimple Website: http://get-simple.info/

============================================================================================
LICENSE:

This software package is licensed under the GNU GENERAL PUBLIC LICENSE v3. 
LICENSE.txt is located below.

It would be great if you would link back to blog.orkunsoylu.com if you use Light theme.

============================================================================================
REQUIREMENTS:

GetSimple v3.1 or higher

Download GetSimple: http://get-simple.info/download/

============================================================================================
INSTALLATION:

Please see: http://get-simple.info/wiki/themes:installation

============================================================================================
DISCLAIMER:

I cannot be held liable for any information loss, corruption or anything else that may 
happen to your site while it is using AcidMind theme.

============================================================================================
LICENSE:

Light Theme for GetSimple Content Management System
Copyright (C) 2012  Orkun Soylu

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    For a copy of the GNU General Public License you should visit
    http://www.gnu.org/licenses/
============================================================================================