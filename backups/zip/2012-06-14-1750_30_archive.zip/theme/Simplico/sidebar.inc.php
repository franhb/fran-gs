<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }

/*
@File: sidebar.php
@Package: GetSimple
@Action: simplico theme for GetSimple CMS
@Author: maciej kopala mdesigns.pl
*/
?>

<aside >

	<div class="sidebar">
		<?php get_component('sidebar');	?>
	</div>

</aside>